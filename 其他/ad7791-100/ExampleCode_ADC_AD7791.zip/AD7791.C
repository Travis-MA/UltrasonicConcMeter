/*********************************************************************

 Author        : ADI - Apps            www.analog.com/MicroConverter

 Date          : September 2003

 File          : AD7791.c

 Hardware      : ADuC832

 Description   :

*********************************************************************/

#include<stdio.h>
#include<aduc832.h>
/******************************************************************
DEFINE CONTROL PINS OF ADUC832 FOR THE PURPOSE OF AD7730 CONTROL.
Customers should define the pins according to their design.
If P0 is used as the control port, pull-up resistors should be added to each pin of P0.
******************************************************************/
sbit CS=0x0A6;
sbit DIN=0x0B4;
sbit DOUT=0x0B5;
sbit DRDY=0x0B3;

sbit SCLOCK=0x0A7;

void writetoreg(unsigned char);
void readfromreg(int);
void read(int);
void main()
{

int k;
/* Set up UART */
T3CON = 0x082;
T3FD = 0x02D;
SCON   = 0x052;

/* PRECONFIGURE...*/
k=32;
SCLOCK=1;
printf("\n");
 CS=0;		  //to keep DIN=1 for 32 sclock to reset the part
 DIN=1;
 while(k--)
{SCLOCK=0;
 SCLOCK=1;}
 CS=1;		  
writetoreg(0x10); //write to communication register. The next step is writing to mode REGISTER
writetoreg(0x02); //set the mode register as continuous conversion mode. bipolar mode.buffered

writetoreg(0x18); //write to communication register. The next step is read from mode REGISTER
readfromreg(8);
printf("\n");
writetoreg(0x28); //write to communication register. The next step is read from filter REGISTER
readfromreg(8);
printf("\n");
writetoreg(0x08); //write to communication register. The next step is read from status REGISTER
readfromreg(8);
printf("\n");


writetoreg(0x3C); //write to communication register. The next step is read from data register continuously
read(200);

writetoreg(0x10); //write to communication register. The next step is writing to mode register
writetoreg(0x0C2); //put ADC into powerdown mode.
writetoreg(0x18); //write to communication register. The next step is read from mode REGISTER
readfromreg(8);
printf("\nfinished");
}


void writetoreg(byteword)
unsigned char byteword;

{
unsigned char temp;
int i;
CS=0;
temp=0x80;
for(i=0;i<8;i++)
	{
 if((temp&byteword)==0)
      DIN=0;
 else DIN=1;
      SCLOCK=0;
	   SCLOCK=1;

 temp=temp>>1;
	}
CS=1;
}

void readfromreg(bytenumber)
int bytenumber;
{
 int j;
   unsigned char temp1;
   DIN=0;
   CS=0;

   temp1=0x00;

   for(j=0;j<bytenumber;j++)
     	{
     	SCLOCK=0;


     	 if(DOUT==0)
     	 temp1=temp1<<1;
	 else
	 {temp1=temp1<<1;
	 temp1=temp1+0x01;}
            SCLOCK=1;
         if(j==7||j==15||j==23)
          { printf("%02BX",temp1);
           temp1=0x00;
           }


	  }

CS=1;
  }




void read(readtime)
int readtime;
{
 unsigned char temp1;
int i,j;
DIN=0;
   CS=0;
temp1=0x00;
for(i=0;i<readtime;i++)
	{
	 while(DRDY);

        for(j=0;j<24;j++)
     	{SCLOCK=0;

     	 if(DOUT==0)
     	 temp1=temp1<<1;
	 else
	 {temp1=temp1<<1;
	 temp1=temp1+0x01;}
	   SCLOCK=1;
         if(j==7||j==15||j==23)
          { printf("%02BX",temp1);
           temp1=0x00;
           }
          }
          printf("\n");


	}

	while(DRDY);
	writetoreg(0x38); //stop continuous read mode
	printf("\n\n\n");

      CS=1;

}


